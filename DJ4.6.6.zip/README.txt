==Dungeon Junkie 4.6.5==

Thank you for downloading Dungeon Junkie!

It means the world to us back at DJHQ that you are showing an interest in our game. Please take some time when you can to check out the bitsy engine that helped us turn our dream into a reality!

This is the seventh of many releases that we'll be developing, leading up to a final version that will most likely be for sale. This version fixed a slight oversight I made (forgetting to add the music to the source) and also changed the color scheme. We're stepping away from black and white and moving toward a new, colorful version of the game. We hope you enjoy this version as much as we do!(^-^)

Oh yeah, there's also a boss battle at the end.

Thank you again!

~The DJ Team