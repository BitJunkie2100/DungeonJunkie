==Dungeon Junkie 4.7.4==

Thank you for downloading Dungeon Junkie!

It means the world to us back at DJHQ that you are showing an interest in our game. Please take some time when you can to check out the bitsy engine that helped us turn our dream into a reality!

This is the eighth of many releases that we'll be developing, leading up to a final version that will most likely be for sale. This version fixed a problem involving backtrack distances. We hope you enjoy this version as much as we do!(^-^)

Thank you again!

~The DJ Team