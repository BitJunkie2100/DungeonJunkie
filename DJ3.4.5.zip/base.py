import time, getpass, dungeonone

def menu():
    print("Dungeon Junkie")
    print("ver. 2.1.4")
    print("Developed by Cole Warren")
    print("""
-Start Game(1)

-How To Play(2)

-Credits(3)

-Quit(4)    
    """)
    c = input(">")

    if c is "1":
        gamestart()
    elif c is "2":
        help()
    elif c is "3":
        credits()
    elif c is "4":
        quitgame()
    elif c is "5":
        cheat()
    else:
        print("Command Not Found")

def gamestart():
    dungeonone.main()

def help():
    print('''
Dungeon Junkie is a very easy game to play.
The only two skills you need are the ability to read and explore.
	
In each room of the dungeon you will be presented with options, either to
move to another room or examine the one you're in.
Simply entering the number corresponding to each option will select it 
and move you on.
	
Item Index:
│ - Blue Key (Blue Key needed)
─ - Red Door (Red Key needed) 
P - YOU
F - The Artifact. Collecting this will end the dungeon.
The rest of the items are hidden and you must examine rooms to find them.
	
Simply follow the instructions on the screen and you'll do fine!
	''')
    time.sleep(2)
    menu()

def credits():
    print('''
    This game was designed and programmed by Cole Warren with original Concept Work and Pixel Art by Ian Eisenhower)
	This program was distributed to the public at no charge. If you paid money for this, you have been royally screwed.)
	Join our Discord Server and subscribe to our newsletter! (Link at the top of the source)
    ''')
    time.sleep(2)
    menu()

def quitgame():
    print("Are you sure you want to quit?")
    time.sleep(1)
    print("Yes(1)/N(2)")

    c = input(">")

    if c is "1":
        quit()
    elif c is "2":
        menu()
    else:
        print("Command Not Found")
        time.sleep(1)
        quitgame()

def cheat():
    rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug = LoadGame()
    if cheater is "1":
        print("I don't think so",getpass.getuser()+". (-_- )")
        time.sleep(1)
        print("You already got the hidden blue key")
        time.sleep(1)
        print("What else do you want?")
        time.sleep(1)
        print("All the Items?")
        time.sleep(1)
        print("The Biggest Score?")
        time.sleep(1)
        print("Well to bad for you")
        time.sleep(1)
        print("You're going to lose your free blue key now.")
        time.sleep(1)
        print("Blue Key (1) Lost")
        time.sleep(1)
        print("Have Fun finding the Real blue key")
        bk = 0
        cheater = 2
        time.sleep(1)
        SaveGame(rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug)
        menu()
        
    elif cheater is "2":
        print("You really like to cheat don't you")
        time.sleep(1)
        print("Well now I have no other choice but to Exit the program for you.")
        cheater = 3
        time.sleep(2)
        SaveGame(rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug)
        quit()
    elif cheater is "3":
        print("I don't think so. (-_- )")
        time.sleep(1)
        print("You had your chance.")
        time.sleep(1)
        print("So go away")
        time.sleep(2)
        quit()
	  
    else:
        print("Congrats You found a hidden blue key")
        bk = 1
        time.sleep(1)
        print("Blue Key (1) Obtained")
        time.sleep(1)
        cheater = 1
        SaveGame(rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug)
        menu()


def SaveGame(rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug):
    savvar = "" 
    savvar += str(rk)
    savvar += str(bk)
    savvar += str(ga)
    savvar +=  str(bcone)
    savvar +=  str(sk)
    savvar +=  str(st)
    savvar +=  str(sw)
    savvar += str(rn)
    savvar +=  str(fsone)
    savvar +=  str(rd)
    savvar +=  str(cheater)
    savvar +=  str(cheaterc)
    savvar +=  str(debug)
    f = open("Save.sav","w")
    f.write(savvar)
    f.close()

def LoadGame():
    f = open("Save.sav","r")
    savvar = f.read()
    f.close()
    
    rk = savvar[0]
    bk = savvar[1]
    ga = savvar[2]
    bcone = savvar[3]
    sk = savvar[4]
    st = savvar[5]
    sw = savvar[6]
    rn = savvar[7]
    fsone = savvar[8]
    rd = savvar[9]
    cheater = savvar[10]
    cheaterc = savvar[11]
    debug = savvar[12]
    if debug is "1":
        print( "rk: "+rk,"bk:"+bk,"ga:"+ga,"bcone:"+bcone,"sk:"+sk,"st:"+st,"sw:"+sw,"rn:"+rn,"fsone:"+fsone,"rd:"+rd,"cheater:"+cheater,"cheaterc:"+cheaterc,"debug:"+debug)
    return rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug

if __name__ == "__main__":
    rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug = LoadGame()

    menu()