import time, base

def main():
    intro()
    startgame()

def intro():
    print("Welcome to Dungeon Junkie - A Completely Text Based Dungeon Crawler")
    time.sleep(1)
    print("This is the first dungeon of the game. If you make your way through all 6 dungeons, you win.")
    time.sleep(1)
    print("Good Luck!")
    time.sleep(1)

def startgame():
    def one():
        rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug = base.LoadGame()
        if rd is "0":
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║           ║ P ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║       ║
    ║   ╚╡─╞╬════   ║   ║   ╒═══╣
    ║       ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
    ''')
        else:
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║           ║ P ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║       ║
    ║   ╚╡ ╞╬════   ║   ║   ╒═══╣
    ║       ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
    ''')
        print("--------------------------------------------------------------------------------")
        print('''
    -Go South(1)

    -Examine Room(2)
	    ''')
        c = input(">")
        if c is "1":
            two()
        elif c is "2":
            print("The room smells like smoke. This is probably because you blew up the entrance, you bum.")
            time.sleep(1)
            one()
        else:
            print("Command not found")
            time.sleep(1)
            one()

    def two():
        rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug = base.LoadGame()
        if rd is "0":
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║     P ║
    ║   ╚╡─╞╬════   ║   ║   ╒═══╣
    ║       ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
    ''')
        else:
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║     P ║
    ║   ╚╡ ╞╬════   ║   ║   ╒═══╣
    ║       ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
    ''')
        print("--------------------------------------------------------------------------------")
        print('''
    -Go West(1)

    -Go North(2)

    -Examine Room(3)
	    ''')
        c = input(">")
        if c is "1":
            three()
        elif c is "2":
            one()
        elif c is "3":
            print("The floor creaks when you step on it. Waterfalls collapse on the ground near the entrance.")
            time.sleep(1)
            two()

    def three():
        rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug = base.LoadGame()
        if rd is "0":
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║ P     ║
    ║   ╚╡─╞╬════   ║   ║   ╒═══╣
    ║       ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	    ''')
        else:
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║ P     ║
    ║   ╚╡ ╞╬════   ║   ║   ╒═══╣
    ║       ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	    ''')
        print("--------------------------------------------------------------------------------")
        print('''
    -Go South(1)

    -Go East(2)

    -Examine Room(3)
	    ''')
        c = input(">")
        if c is "1":
            four()
        elif c is "2":
            two()
        elif c is "3":
            print("You check all around the room. Nothing but a pile of bones in the corner. Gross.")
            time.sleep(1)
            three()
        else:
            print("Command not found")
            time.sleep(1)
            three()

    def four():
        rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug = base.LoadGame()
        if rd is "0":
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║       ║
    ║   ╚╡─╞╬════   ║   ║   ╒═══╣
    ║       ║       ║     P │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	    ''')
        else:
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║       ║
    ║   ╚╡ ╞╬════   ║   ║   ╒═══╣
    ║       ║       ║     P │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	    ''')
        print("--------------------------------------------------------------------------------")
        if bk is "1":
            print('''
    -Go North(1)

    -Go East(2)(Collect Artifact)

    -Go West(3)

    -Examine Room(4)
    ''')
        else:
            print('''
    -Go North(1)

    -Go East(2)(Locked Door)

    -Go West(3)

    -Examine Room(4)
	    ''')
        c = input(">")
        if c is "1":
            three()
        elif c is "2":
            if bk is "1":
                artone()
            elif bk is "0":
                print("The door is locked. You need the Blue Key (1)")
                time.sleep(1)
                four()
        elif c is "3":
            five()
        elif c is "4":
            if ga is "0":
                print("You walk around the room. In the corner you find a Gauntlet. You put it on and a wave of power passes over you.")
                time.sleep(1)
                print("Gauntlet Collected!")
                ga = 1
                time.sleep(1)
                base.SaveGame(rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug)
                four()
            elif ga is "1":
                print("The gauntlet has already been collected.")
                check = 1
                time.sleep(1)
                four()
            elif check is 1:
                print("Looking at the room now, you see a Door with a key hole. By the looks of it, you will need a key to open it.")
                time.sleep(1)
                four()
            else:
                print("Command not found")
                time.sleep(1)
                four()
            
    def five():
        rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug = base.LoadGame()
        if rd is "0":
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║       ║
    ║   ╚╡─╞╬════   ║   ║   ╒═══╣
    ║       ║       ║ P     │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	''')
        else:
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║       ║
    ║   ╚╡ ╞╬════   ║   ║   ╒═══╣
    ║       ║       ║ P     │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	''')
        print("--------------------------------------------------------------------------------")
        print('''
    -Go North(1)

    -Go East(2)

    -Examine Room(3)
	''')
	
        c = input(">")
        if c is "1":
            six()
        elif c is "2":
            four()
        elif c is "3":
            print("The room smells of decay. You trip over the arm of a less-fortunate explorer.")
            time.sleep(1)
            five()
        else:
            print("Command not found")
            time.sleep(1)
            five()        
    
    def six():
        rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug = base.LoadGame()
        if rd is "0":
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║         P ║       ║
    ║   ╚╡─╞╬════   ║   ║   ╒═══╣
    ║       ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	''')
        else:
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║         P ║       ║
    ║   ╚╡ ╞╬════   ║   ║   ╒═══╣
    ║       ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	''')
        print("--------------------------------------------------------------------------------")
        print('''
    -Go North(1)

    -Go South(2)

    -Go West(3)

    -Examine Room(4)
	''')
        c = input(">")
        if c is "1":
            seven()
        elif c is "2":
            five()
        elif c is "3":
            ten()
        elif c is "4":
            print("You examine the strange markings on the walls of the dungeon. They don't look egyptian in origin, but something similar")
            time.sleep(1)
            six()
        else:
            print("Command not found")
            time.sleep(1)
            six()

    def seven():
        rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug = base.LoadGame()
        if rd is "0":
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║     P     ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║       ║
    ║   ╚╡─╞╬════   ║   ║   ╒═══╣
    ║       ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	''')
        else:
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║     P     ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║       ║
    ║   ╚╡ ╞╬════   ║   ║   ╒═══╣
    ║       ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	''')
        print("--------------------------------------------------------------------------------")
        print('''
    -Go East(1)

    -Go West(2)

    -Go South(3)

    -Examine Room(4)
	''')
        c = input(">")
        if c is "1":
            eight()
        elif c is "2":
            nine()
        elif c is "3":
            six()
        elif c is "4":
            print("Large stones form a line against the wall. You're descending deeper into the dungeon")
            time.sleep(1)
            seven()
        else:
            print("Command not found")
            time.sleep(1)
            seven()

    def eight():
        rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug = base.LoadGame()
        if rd is "0":
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║         P ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║       ║
    ║   ╚╡─╞╬════   ║   ║   ╒═══╣
    ║       ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	''')
        else:
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║         P ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║       ║
    ║   ╚╡ ╞╬════   ║   ║   ╒═══╣
    ║       ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	''')
        print("--------------------------------------------------------------------------------")
        print('''
    -Go West(1)

    -Examine Room(2)
	''')
        c = input(">")
        if c is "1":
            seven()
        elif c is "2":
            print("You find a small hamster, running in his wheel. What the actual hell is going on?")
            time.sleep(1)
            eight()
        else:
            print("Command not found")
            time.sleep(1)
            eight()

    def nine():
        rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug = base.LoadGame()
        if rd is 0:
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║ P         ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║       ║
    ║   ╚╡─╞╬════   ║   ║   ╒═══╣
    ║       ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	''')
        else: 
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║ P         ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║       ║
    ║   ╚╡ ╞╬════   ║   ║   ╒═══╣
    ║       ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	''')
        print("--------------------------------------------------------------------------------")
        print('''
    -Go East(1)

    -Examine Room(2)
	''')
        c = input(">")
        if c is "1":
            seven()
        elif c is "2":
            print("There's a small chest in the middle of the room. You choose not to open it out of paranoia.")
            time.sleep(1)
            nine()
        else:
            print("Command not found")
            time.sleep(1)
            nine()

    def ten():
        rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug = base.LoadGame()
        if rd is "0":
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║     P     ║       ║
    ║   ╚╡─╞╬════   ║   ║   ╒═══╣
    ║       ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	''')
        else:
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║     P     ║       ║
    ║   ╚╡ ╞╬════   ║   ║   ╒═══╣
    ║       ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
''')
        print("--------------------------------------------------------------------------------")
        print('''
    -Go East(1)

    -Go South(2)

    -Go West(3)

    -Examine Room(4)
	''')
        c = input(">")
        if c is "1":
            six()
        elif c is "2":
            eleven()
        elif c is "3":
            thirteen()
        elif c is "4":
            print("A single pint of mead sits on a cold, stone table. The cobwebs tell you it's aged to perfection. ")
            time.sleep(1)
            ten()
        else:
            print("Command not found")
            time.sleep(1)
            ten()

    def eleven():
        rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug = base.LoadGame()
        if rd is "0":
            print('''	
    ╔═══════════╦═══════════╦═══╗
    ║           ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║       ║
    ║   ╚╡─╞╬════   ║   ║   ╒═══╣
    ║       ║     P ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	''')
        else:
            print('''	
    ╔═══════════╦═══════════╦═══╗
    ║           ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║       ║
    ║   ╚╡ ╞╬════   ║   ║   ╒═══╣
    ║       ║     P ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	''')
        print("--------------------------------------------------------------------------------")
        print('''
    -Go North(1)

    -Go West(2)

    -Examine Room(3)
	''')
        c = input(">")
        if c is "1":
            ten()
        elif c is "2":
            twelve()
        elif c is "3":
            print("You stroll into the room, almost stepping into a pit of quicksand.")
            time.sleep(1)
            eleven()
        else:
            print("Command not found")
            time.sleep(1)
            eleven()

    def twelve():
        rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug = base.LoadGame()
        if rd is "0":
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║       ║
    ║   ╚╡─╞╬════   ║   ║   ╒═══╣
    ║       ║ P     ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	    ''')
        else: 
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║       ║
    ║   ╚╡ ╞╬════   ║   ║   ╒═══╣
    ║       ║ P     ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	    ''')
        print("--------------------------------------------------------------------------------")
        print('''
    -Go East(1)

    -Examine Room(2)
	    ''')
        c = input(">")
        if c is "1":
            eleven()
        elif c is "2":
            print("You lean into the wall. It's like it bends inwards. You're about touch the brick, but two yellow eyes open in front of you.")
            time.sleep(1)
            twelve()
        else:
            print("Command not found")
            time.sleep(1)
            twelve()
    
    def thirteen():
        rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug = base.LoadGame()
        if rd is "0":
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║ P         ║       ║
    ║   ╚╡─╞╬════   ║   ║   ╒═══╣
    ║       ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	    ''')
        else:
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║ P         ║       ║
    ║   ╚╡ ╞╬════   ║   ║   ╒═══╣
    ║       ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	    ''')
        print("--------------------------------------------------------------------------------")
        print('''
    -Go North(1)

    -Go East(2)

    -Examine Room(3)
	    ''')
        c = input(">")
        if c is "1":
            fourteen()
        elif c is "2":
            ten()
        elif c is "3":
            print("The room quakes when you step. Very unstable. You should finish up in here quickly.")
            time.sleep(1)
            thirteen()
        else:
            print("Command not found")
            time.sleep(1)
            thirteen()

    def fourteen():
        rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug = base.LoadGame()
        if rd is "0":
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║         P ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║       ║
    ║   ╚╡─╞╬════   ║   ║   ╒═══╣
    ║       ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	    ''')
        else:
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║         P ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║       ║
    ║   ╚╡ ╞╬════   ║   ║   ╒═══╣
    ║       ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	    ''')
        print("--------------------------------------------------------------------------------")
        print('''
    -Go South(1)

    -Go West(2)

    -Examine Room(3)
	    ''')
        c = input(">")
        if c is "1":
            thirteen()
        elif c is "2":
            fifteen()
        elif c is "3":
            if bk is "0":
                print("You walk into the room and instantly get dizzy. It's so...familiar. You balance yourself and see a key sitting on a pedestal in front of you. You pick it up.")
                time.sleep(1)
                print("Blue Key (1) Collected!")
                time.sleep(1)
                bk = 1
                base.SaveGame(rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug)
                fourteen()
            elif bk is "1":
                print("The Blue Key (1) has already been collected.")
                time.sleep(1)
                check = 1
                fourteen()
            elif check is 1:
                print("The Room is filled with mist comming off the surounding walls, and there is a pedestal in the midddle of the room, that had the blue key.")
            else:
                print("Command not found")
                time.sleep(1)
                fourteen()

    def fifteen():
        rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug = base.LoadGame()
        if rd is "0":
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║     P     ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║       ║
    ║   ╚╡─╞╬════   ║   ║   ╒═══╣
    ║       ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	''')
        else:
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║     P     ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║       ║
    ║   ╚╡ ╞╬════   ║   ║   ╒═══╣
    ║       ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	''')
        print("--------------------------------------------------------------------------------")
        print('''
    -Go East(1)

    -Go South(2)

    -Go West(3)

    -Examine Room(4)
	''')
        c = input(">")
        if c is "1":
            fourteen()
        elif c is "2":
            sixteen()
        elif c is "3":
            seventeen()
        elif c is "4":
            print("Fountains. There's a fountain for every corner of the room. Strange.")
            time.sleep(1)
            fifteen()
        else:
            print("Command not found")
            time.sleep(1)
            fifteen()

    def sixteen():
        rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug = base.LoadGame()
        if rd is 0:
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║ P ║           ║       ║
    ║   ╚╡─╞╬════   ║   ║   ╒═══╣
    ║       ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	    ''')
        else:
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║ P ║           ║       ║
    ║   ╚╡ ╞╬════   ║   ║   ╒═══╣
    ║       ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	    ''')
        print("--------------------------------------------------------------------------------")
        print('''
    -Go South(1)

    -Go North(2)

    -Examine Room(3)
	    ''')
        c = input(">")
        if c is "1":
            if rk is "1":
                rd = 1
                base.SaveGame(rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug)
                eighteen()
            elif rk is "0":
                print("The door is locked. You need the Red Key (2)")
                time.sleep(1)
                sixteen()
        elif c is "2":
            fifteen()
        elif c is "3":
            print("Another skeleton is shackled to the wall. The difference? You swear that this one moved")
            time.sleep(1)
            sixteen()
        else:
            print("Command not found")
            time.sleep(1)
            sixteen()

    def seventeen():
        rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug = base.LoadGame()
        if rd is "0":
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║ P         ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║       ║
    ║   ╚╡─╞╬════   ║   ║   ╒═══╣
    ║       ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	    ''')
        else:
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║ P         ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║       ║
    ║   ╚╡ ╞╬════   ║   ║   ╒═══╣
    ║       ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	    ''')
        print("--------------------------------------------------------------------------------")
        print('''
    -Go East(1)

    -Examine Room(2)
	    ''')
        c = input(">")
        if c is "1":
            fifteen()
        elif c is "2":
            if rk is "0":
                print("Wedged between two of the cold bricks in the wall is a red key. You yank it out.")
                time.sleep(1)
                print("Red Key (2) Collected!")
                rk = 1
                time.sleep(1)
                base.SaveGame(rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug)
                seventeen()
            elif rk is "1":
                print("The Red Key (2) has already been collected.")
                seventeen()
            elif check is 1:
                print("The Room you are in is full of misalined bricks, you are amazed by how this room is still standing.")
                seventeen()
            else:
                print("Error - Internal Variable Contradiction")
        else:
            print("Command not found")
            time.sleep(1)
            seventeen()

    def eighteen():
        rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug = base.LoadGame()
        if rd is "0":
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║       ║
    ║   ╚╡─╞╬════   ║   ║   ╒═══╣
    ║     P ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	    ''')
        else:
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║       ║
    ║   ╚╡ ╞╬════   ║   ║   ╒═══╣
    ║     P ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	    ''')
        print("--------------------------------------------------------------------------------")
        print('''
    -Go North(1)

    -Go West(2)

    -Examine Room(3)
	    ''')
        c = input(">")
        if c is "1":
            sixteen()
        elif c is "2":
            nineteen()
        elif c is "3":
            print("The room smells like old wood. There's a chest nearby.")
            time.sleep(1)
            eighteen()
        else:
            print("Command not found")
            time.sleep(1)
            eighteen()

    def nineteen():
        rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug = base.LoadGame()
        if rd is "0":
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║       ║
    ║   ╚╡─╞╬════   ║   ║   ╒═══╣
    ║ P     ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	    ''')
        else:
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║   ║   ║           ║       ║
    ║   ╚╡ ╞╬════   ║   ║   ╒═══╣
    ║ P     ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	    ''')
        print("--------------------------------------------------------------------------------")
        print('''
    -Go North(1)

    -Go East(2)

    -Examine Room(3)
	    ''')
        c = input(">")
        if c is "1":
            twenty()
        elif c is "2":
            eighteen()
        elif c is "3":
            print("You step awkwardly into the room. You're exhausted.")
            time.sleep(1)
            nineteen()
        else:
            print("Command not found")
            time.sleep(1)
            nineteen()

    def twenty():
        rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug = base.LoadGame()
        if rd is "0":
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║ P ║   ║           ║       ║
    ║   ╚╡─╞╬════   ║   ║   ╒═══╣
    ║       ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	    ''')
        else:
            print('''
    ╔═══════════╦═══════════╦═══╗
    ║           ║           ║   ║
    ╠═══╗   ║   ╚════   ╔═══╝   ║
    ║ P ║   ║           ║       ║
    ║   ╚╡ ╞╬════   ║   ║   ╒═══╣
    ║       ║       ║       │ F ║
    ╚═══════╩═══════╩═══════╧═══╝
	    ''')
        print("--------------------------------------------------------------------------------")
        print('''
    -Go South(1)

    -Examine Room(2)
	    ''')
        c = input(">")
        if c is "1":
            nineteen()
        elif c is "2":
            if bcone is "0":
                print("You found the bonus chest! +500 points!")
                time.sleep(1)
                bcone = 1
                base.SaveGame(rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug)
                twenty()
            elif bcone is "1":
                check = 1
                print("You've already collected the bonus chest.")
                time.sleep(1)
                twenty()
            elif check is 1:
                print("What are you still doing here?")
                check = 2
                time.sleep(1)
                twenty()
            elif check is 2:
                print("Do you like the look of this chest?")
                time.sleep(1)
                twenty()
            else:
                print("Error. Internal Variable Contradiction")
        else:
            print("Command not found")
            time.sleep(1)
            twenty()

    def artone():
        rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug = base.LoadGame()
        if rd is "0":
            print('''
      ╔═══════════╦═══════════╦═══╗
      ║           ║           ║   ║
      ╠═══╗   ║   ╚════   ╔═══╝   ║
      ║   ║   ║           ║       ║
      ║   ╚╡-╞╬════   ║   ║   ╒═══╣
      ║       ║       ║       │ P ║
      ╚═══════╩═══════╩═══════╧═══╝
  	    ''')
        else:
            print('''
      ╔═══════════╦═══════════╦═══╗
      ║           ║           ║   ║
      ╠═══╗   ║   ╚════   ╔═══╝   ║
      ║   ║   ║           ║       ║
      ║   ╚╡ ╞╬════   ║   ║   ╒═══╣
      ║       ║       ║       │ P ║
      ╚═══════╩═══════╩═══════╧═══╝
      ''')
        print("--------------------------------------------------------------------------------")
        rks,bks,gas,bcones = 0,0,0,0
        if rk is "1":
            rks = 50
        if bk is "1":
            bks = 50
        if ga is "1":
            gas = 50
        if bcone is "1":
            bcones = 500
        if cheater is "1":
            print("Do you really Think that you could of gotten away with that free blue key?")
            time.sleep(1)
            print("Well I'll let it slide this one time, but next time you do it again there will be consequences.")
            time.sleep(1)
            print("Dungeon One Completed!")
            cheaterc = 1
            fsones = bks + rks + gas + bcones + 200
            print("Final Score: ",fsones,"You Cheater")
            base.SaveGame(rk,bk,ga,bcone,sk,st,sw,rn,fsone,rd,cheater,cheaterc,debug)
            print("Press Enter to continue to Dungeon Two")
            c = input(">")
            
        elif cheaterc is "1":
            print("So you did it again, hmmm...")
            time.sleep(1)
            print("Why do you keep doing on cheating?")
            time.sleep(1)
            print("Do you just like to cheat?")
            time.sleep(1)
            print("Do you want to get through the game as fast as possable?")
            time.sleep(1)
            print("Well there is one thing I could do...")
            time.sleep(1)
            print("I'll just make your FINAL SCORE 0")
            time.sleep(1)
            print("Now I want to see your face when you see your final score")
            time.sleep(2)
            print("Dungeon One Completed!")
            fsones = 0
            print("Final Score: ",fsones,"You Cheater")
            print("Press Enter to continue to Dungeon Two")
            c = input(">")
        else:
            print("Dungeon One Completed!")
            fsones = bks + rks + gas + bcones + 200
            print("Final Score: ",fsones)
            print("Press Enter to continue to Dungeon Two")
            c = input(">")
        dungeontwointro()

    def dungeontwointro():
        print("Thank you for playing Dungeon Junkie! Dungeon Two is currently in development.")
        print("But in the meantime, join our Official Discord for updates and challenges!")
        print("Your continued support helps us make this dream a reality!")
        print("Thank you again!")
        print("~ The Dungeon Junkie Team")
        time.sleep(3)
        base.menu()
    one()


if __name__ == "__main__":
    main()